<section class="text centered marginbottom paddingtop paddingbottom">
	<h2 class="grey">Coronavirus API Public Health Initiative</h2>
    <h1>How to use the Coronavirus API?</h1>
</section>

<section class="text">

	<h3>Official state data in csv format</h3>
	<p>http://coronavirusapi.com/states.csv</p>

	<h3>Time series in csv format</h3>
	<p>http://coronavirusapi.com/time_series.csv</p>

	<h3>Time series for a given state</h3>
	<p>http://coronavirusapi.com/getTimeSeries/[2 letter state abbreviation]</p>

</section>


