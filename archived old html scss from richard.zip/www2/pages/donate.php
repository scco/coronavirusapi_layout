<section class="text centered marginbottom paddingtop paddingbottom">
	<h2 class="grey">Coronavirus API Public Health Initiative</h2>
    <h1>Donate</h1>
    <p>Financial contributions are very welcome.</p>
</section>


<section class="grid paddingtop paddingbottom">
	
	<article class="card">
		<h2>Bitcoin</h2>
		<h3>1LG9dUf39dCKAEFcKm6guNhadTJwNqj44J</h3>
	</article>

	<article class="card">
		<h2>Bitcoin Cash</h2>
		<h3>qrf504gk8n6sujjegwastxqdz2lv5vlv65pxs03s7k</h3>
	</article>

	<article class="card">
		<h2>Ethereum</h2>
		<h3>0x549ffFB83ac67Ca1Ae47668ac3cAAE3e0c77a9bd</h3>
	</article>

	<article class="card">
		<h2>Stellar</h2>
		<h3>GCVRV67LBHTMVXKDAJSW3S3ASASI6EJWQU2LYEOGKPSJEY42PYRAUDME</h3>
	</article>

	<article class="card">
		<h2>Vechain</h2>
		<h3>0xa81cd7a8272E053A18a13459425FFd260105EDd9</h3>
	</article>

</section>






