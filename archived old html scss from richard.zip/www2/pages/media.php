<section class="text centered marginbottom paddingtop paddingbottom">
	<h2 class="grey">Coronavirus API Public Health Initiative</h2>
    <h1>Media</h1>
</section>


<section class="grid paddingtop paddingbottom">

	<article class="card">
		<a href="https://www.coindesk.com/the-coronavirus-api-delivers-vital-statistics-unmediated-by-government-hands?utm_source=&utm_medium=&utm_campaign=&clid=00Q1I00000KKcgnUAD">
		<h2>Coindesk</h2>
		<h3>The Coronavirus API Delivers Vital Statistics Unmediated by Government Hands</h3>
		<span>Read Article</span>
		</a>
	</article>

	<article class="card">
		<a href="https://youtu.be/O-_NeLJ6WiY">
		<h2>law.MIT.edu</h2>
		<h3>Spotlight on Coronavirusapi</h3>
		<span>Read Interview</span>
		</a>
	</article>




</section>







