<section class="text centered marginbottom paddingtop paddingbottom">
	<h2 class="grey">Coronavirus API Public Health Initiative</h2>
    <h1>New Jersy</h1>
    <p>Offucuak COVID-19 counts for NJ</p>
    <p class="grey"><i>Website crawled 4.7 hours ago</i></p>

	<section class="grid">
		<article class="card">
			<h2>157,449</h2>
			<h3>Tested</h3>
			
		</article>

		<article class="card">
			<h2>78,467</h2>
			<h3>Positive</h3>
			
		</article>

		<article class="card">
			<h2>3,840</h2>
			<h3>Deaths</h3>
			
		</article>
	</section>

</section>



<section class="text centered paddingtop paddingbottom">
	<h1>Total number tested over time</h1>
</section>


<section class="fullscreen" id="chart"></section>





<script src="https://ajax.googleapis.com/ajax/libs/d3js/5.15.1/d3.min.js"></script>
<script src="js/apexcharts.min.js"></script>


<script>
    var options = {
      series: [{
        name: "Desktops",
        data: [10, 41, 35, 51, 49, 62, 69, 91, 148]
    }],
      chart: {
      height: 500,
      type: 'line',
      zoom: {
        enabled: false
      }
    },

	colors:['#374255', '#374255', '#374255'],

    dataLabels: {
      enabled: false
    },
    stroke: {
      curve: 'straight',
      width: 2
    },
    title: {
      text: 'Total number tested over time',
      align: 'left'
    },
    grid: {
      row: {
        colors: ['#ffffff', 'transparent'], // takes an array which will be repeated on columns
        opacity: 0.5
      },
    },
    xaxis: {
      categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'],
    }
    };

    var chart = new ApexCharts(document.querySelector("#chart"), options);
    chart.render();

</script>