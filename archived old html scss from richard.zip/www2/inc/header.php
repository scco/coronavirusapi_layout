<!DOCTYPE html>
<html lang="en">
<head>
	<title>Coronavirus API Public Health Initiative</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">



	<link href="css/app.css" type="text/css" rel="stylesheet" media="screen,projection"/>
	<meta name="robots" content="index,follow" />
	<meta name="audience" content="Alle" />
	<meta name="revisit-after" content="7 days" />
	<meta name="description" content="">
	<meta name="keywords" content="">
</head>

<body>


